If you're getting "(Out of sync)" message, wait ~1-2 minutes, and the client should start syncing.
If you are still having trouble, copy educoin.conf to your user's roaming EduCoin directory and restart the client.

That directory is located @ (Windows 7) -- C:\Users\[YOUR_USER]\AppData\Roaming\EduCoin