rm -rf /Applications/educoin-qt.app
make -f Makefile
cp -Rp educoin-qt.app /Applications/
